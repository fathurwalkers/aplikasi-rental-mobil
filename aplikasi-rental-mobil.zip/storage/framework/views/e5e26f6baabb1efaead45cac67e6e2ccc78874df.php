<?php $__env->startSection('title', 'Rendra Rental - Home'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .img-fix {
            width: 100%!important; /* You can set the dimensions to whatever you want */
            height: 160px!important;
            object-fit: cover!important;
        }
        .fix-text {
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('alert'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('header-hero'); ?>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.home-header-hero','data' => []]); ?>
<?php $component->withName('home-header-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('info'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('home-body'); ?>

    <section id="daftar-kendaraan">

        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 mb-2">
                <h2 class="section-heading text-center"><strong>Daftar Kendaraan</strong></h2>
                <p class="mb-5 text-center">Pilih kendaraan yang ingin anda Sewa</p>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $kendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 col-lg-4 mb-4">
                <div class="listing d-block  align-items-stretch">
                    <div class="listing-img h-100 mr-4">
                        <img src="<?php echo e(asset('default-img/foto')); ?>/<?php echo e($item->kendaraan_foto); ?>" alt="Image" class="img img-fix">
                    </div>
                    <div class="listing-contents h-100">
                        <h3><?php echo e($item->kendaraan_merk); ?></h3>
                        <div class="rent-price">
                            <strong><?php echo e("Rp " . number_format($item->kendaraan_harga_sewa,0,',','.')); ?> </strong><span class="mx-1">/</span>day
                        </div>
                        <div class="d-block d-md-flex mb-3 border-bottom pb-4 mb-2">
                            <div class="listing-feature pr-4">
                                <span class="caption">Transmisi :</span>
                                <span class="number"><?php echo e($item->kendaraan_jenis_transmisi); ?></span>
                            </div>
                            <div class="listing-feature pr-4">
                                <span class="caption">Body :</span>
                                <span class="number"><?php echo e($item->kendaraan_jenis_body); ?></span>
                            </div>
                            <div class="listing-feature pr-4">
                                <span class="caption">Tipe :</span>
                                <span class="number"><?php echo e($item->kendaraan_tipe); ?></span>
                            </div>
                        </div>
                        <div>
                            
                            <p><a href="#" class="btn btn-primary btn-sm mb-1" data-toggle="modal" data-target="#modalpenyewaan<?php echo e($item->id); ?>">Rental sekarang</a></p>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="modal fade" id="modalpenyewaan<?php echo e($item->id); ?>" tabindex="1" role="dialog" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">

                        <div class="modal-header">
                            <h4 class="modal-title">Form Penyewaan</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">Apakah anda yakin ingin menyewa kendaraan ini?</div>

                        <div class="container">
                            <div class="row">
                                <div class="col-sm-2 col-md-2 col-lg-2">

                                </div>
                                <div class="col-sm-4 col-md-4 col-lg-4">
                                    <h5 class="fix-text">Merk </h5 class="fix-text">
                                    <h5 class="fix-text">Harga Sewa </h5 class="fix-text">
                                    <h5 class="fix-text">Tipe Kendaraan </h5 class="fix-text">
                                    <h5 class="fix-text">Kondisi </h5 class="fix-text">
                                    <h5 class="fix-text">Max Mil </h5 class="fix-text">
                                    <h5 class="fix-text">Tahun </h5 class="fix-text">
                                    <h5 class="fix-text">Jenis Transmisi </h5 class="fix-text">
                                    <h5 class="fix-text">Jenis Body </h5 class="fix-text">
                                </div>
                                <div class="col-sm-4 col-md-4 col-lg-4">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_merk); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e("Rp " . number_format($item->kendaraan_harga_sewa,0,',','.')); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_tipe); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_kondisi); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_max_mil); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_tahun); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_jenis_transmisi); ?> </h5 class="fix-text">
                                    <h5 class="fix-text">: <?php echo e($item->kendaraan_jenis_body); ?> </h5 class="fix-text">
                                </div>
                                <div class="col-sm-2 col-md-2 col-lg-2">

                                </div>
                            </div>
                        </div>

                        <form action="<?php echo e(route('proses-penyewaan', $item->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="container border-dark">

                                <div class="row">
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="rental_durasi">Durasi Penyewaan</label>
                                            <input type="number" class="form-control" id="rental_durasi" placeholder="Durasi penyewaan..." name="rental_durasi">
                                        </div>
                                    </div>
                                    <div class="col-sm-6 col-md-6 col-lg-6">
                                        <div class="form-group">
                                            <label for="rental_satuan_waktu">Satuan Waktu</label>
                                            <select id="rental_satuan_waktu" class="form-control" name="rental_satuan_waktu">
                                                <option selected disabled>Pilih satuan waktu...</option>
                                                <option value="HARI">Hari</option>
                                                <option value="BULAN">Bulan</option>
                                                <option value="JAM">Jam</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="modal-footer">
                                <button type="button" class="btn gray btn-danger" data-dismiss="modal">Batalkan</button>
                                <button type="submit" class="btn btn-info" >
                                    Lanjutkan Penyewaan
                                </button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
            <?php echo e($kendaraan->onEachSide(0)->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('testimonial'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/home/index.blade.php ENDPATH**/ ?>