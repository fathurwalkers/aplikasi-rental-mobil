<?php $__env->startSection('title', 'Rendra Rental - Contact'); ?>

<?php $__env->startPush('css'); ?>
    <style>
        .img-fix {
            width: 100%!important; /* You can set the dimensions to whatever you want */
            height: 160px!important;
            object-fit: cover!important;
        }
        .fix-text {
            font-size: 14px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('home-body'); ?>
<div class="site-section bg-light" id="contact-section">
    <div class="container">

        <div class="row justify-content-center text-center">
            <div class="col-7 text-center mb-3">
                <h2>Kontak Kami</h2>
                <p>Untuk pelayanan dan pengaduan, anda bisa menghubungi kami pada kontak yang tertera dibawah ini. </p>
            </div>
        </div>

        <div class="row">

            

            <div class="col-lg-12 mx-auto">
                <div class="bg-white p-3 p-md-5">
                    <h3 class="text-black mb-4">Contact Info</h3>
                    <ul class="list-unstyled footer-link">
                        <li class="d-block mb-3">
                            <span class="d-block text-black">Alamat :</span>
                            <span>Jl. Raya Palagimata, Ruko Perempatan Rau, Wameo, Kecamatan Batu Poaro, Kota Baubau, Sulawesi Tenggara</span></li>
                        <li class="d-block mb-3"><span class="d-block text-black">No. HP / Telepon :</span><span>(+62) 822 - 1566 - 8874</span></li>
                        <li class="d-block mb-3"><span class="d-block text-black">Email :</span><span>layametravel@gmail.com</span></li>
                    </ul>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/home/kontak.blade.php ENDPATH**/ ?>