<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-header', 'Beranda'); ?>

<?php $__env->startSection('content-body'); ?>

    <?php if($users->login_level == "admin"): ?>
        <div class="row">

            <div class="col-lg-3 col-md-3 col-sm-3 col-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-success">
                        <i class="fas fa-truck"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Kendaraan</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($kendaraan); ?>

                        </div>
                </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 col-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-primary">
                            <i class="fas fa-users"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Customer</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($data); ?>

                        </div>
                </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 col-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-warning">
                            
                            <i class="fas fa-indent"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>Total Penyewaan</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($rental); ?>

                        </div>
                </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-3 col-3">
                <div class="card card-statistic-1">
                    <div class="card-icon bg-warning">
                            
                            <i class="fas fa-file-contract"></i>
                    </div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4>User</h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($login); ?>

                        </div>
                </div>
                </div>
            </div>

        </div>
    <?php endif; ?>

    <?php if($users->login_level == "customer"): ?>

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/dashboard/index.blade.php ENDPATH**/ ?>