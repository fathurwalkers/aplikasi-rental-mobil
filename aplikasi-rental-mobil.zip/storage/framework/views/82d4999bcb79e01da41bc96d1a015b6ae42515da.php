<?php $__env->startSection('title', 'Daftar Customer - Dashboard'); ?>

<?php $__env->startSection('content-header', 'Daftar Customer'); ?>

<?php $__env->startSection('content-header-button'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('datatables')); ?>/datatables.min.css">
<style>
    .cke {
        visibility: visible !important;
    }

    .modal-backdrop.show {
        display: none !important;
    }

    .fix-text {
        font-size: 15px;
    }

    .fix-text-h5 {
        font-size: 12px;
    }

    table.dataTable tbody th,
    table.dataTable tbody td {
        padding: 6px 8px!important;
        border-color: #d8d8d8!important;
        border-top-color: #d8d8d8!important;
        border-right-color: #d8d8d8!important;
        border-bottom-color: #d8d8d8!important;
        border-left-color: #d8d8d8!important;
        table-layout:fixed!important;
        white-space: nowrap!important;
    }

    .button-text-fix {
        font-size: 11px!important;
    }

    table.dataTable {
        color: rgb(0, 0, 0)!important;
    }
</style>


<script src="<?php echo e(asset('ckeditor')); ?>/ckeditor.js"></script>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-body'); ?>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <?php if(session('status')): ?>
            <div class="alert alert-info">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12 col-lg-12">
        <div class="card">
            <div class="card-body">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.data-table-customer','data' => ['customer' => $customer]]); ?>
<?php $component->withName('data-table-customer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['customer' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($customer)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('datatables')); ?>/datatables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#example1').DataTable();
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/dashboard/daftar-customer.blade.php ENDPATH**/ ?>