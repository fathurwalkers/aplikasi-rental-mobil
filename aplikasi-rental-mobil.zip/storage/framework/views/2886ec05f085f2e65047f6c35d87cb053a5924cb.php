<div>
    
    <div class="hero" style="background-image: url('<?php echo e(asset('home')); ?>/images/hero_1.jpg');">

        <div class="container">
          <div class="row align-items-center justify-content-center">
            <div class="col-lg-10">

              <div class="row mb-4">
                <div class="col-lg-7 intro">
                    <h1><strong>Sewa Kendaraan</strong> sekarang juga. </h1>
                </div>
              </div>
              <div class="row">
                  <div class="col-lg-12 col-md-12 col-sm-12">
                    <?php echo $__env->yieldPushContent('alert'); ?>
                  </div>
              </div>

              

            </div>
          </div>
        </div>
      </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/components/home-header-hero.blade.php ENDPATH**/ ?>