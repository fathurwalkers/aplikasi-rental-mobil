<?php $__env->startPush('css'); ?>
<style>

</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content-header', 'Dashboard - Pendaftaran Data Customer'); ?>

<?php $__env->startSection('content-body'); ?>


    <div class="card">
        <div class="card-body">

            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <form action="<?php echo e(route('post-data-customer', $users->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <div class="form-group">
                            <label for="data_foto">Foto</label>
                            <input type="file" class="form-control-file" id="data_foto" name="data_foto">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="form-group">
                            <label for="data_nama_lengkap">Nama Lengkap</label>
                            <input type="text" class="form-control" id="data_nama_lengkap" name="data_nama_lengkap">
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="form-group">
                            <label for="data_jenis_kelamin">Jenis Kelamin</label>
                            <select class="form-control" id="data_jenis_kelamin" name="data_jenis_kelamin">
                                <option selected>Pilih jenis Kelamin</option>
                                <option value="L">Laki-Laki</option>
                                <option value="P">Perempuan</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row mt-4 mb-2">
                    <div class="col-sm-12 col-md-12 col-lg-12 d-flex justify-content-center">
                        <button class="btn btn-md btn-info" type="submit">Simpan Data</button>
                    </div>
                </div>

            </form>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\aplikasi-rental-mobil\resources\views/dashboard/pendaftaran-data-customer.blade.php ENDPATH**/ ?>